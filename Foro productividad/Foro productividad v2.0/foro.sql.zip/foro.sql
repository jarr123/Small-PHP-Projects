-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 13-02-2011 a las 15:16:11
-- Versión del servidor: 5.1.44
-- Versión de PHP: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `foro`
--
CREATE DATABASE `foro` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `foro`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `puntuacion`
--
-- Creación: 13-02-2011 a las 12:50:35
-- Última actualización: 13-02-2011 a las 16:15:14
--

CREATE TABLE IF NOT EXISTS `puntuacion` (
  `indice` int(11) NOT NULL,
  `puntuacion` int(11) NOT NULL,
  PRIMARY KEY (`indice`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `puntuacion`
--

INSERT INTO `puntuacion` (`indice`, `puntuacion`) VALUES
(13, 1),
(12, 0),
(14, 3),
(15, 2),
(16, 0),
(17, 1),
(18, 0),
(19, 0),
(20, 2),
(21, 0),
(22, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tema`
--
-- Creación: 12-02-2011 a las 17:31:40
-- Última actualización: 13-02-2011 a las 16:15:17
--

CREATE TABLE IF NOT EXISTS `tema` (
  `indice` int(11) NOT NULL AUTO_INCREMENT,
  `entradaPrevia` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `email` varchar(30) NOT NULL,
  `descripcion` varchar(300) NOT NULL,
  PRIMARY KEY (`indice`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Volcar la base de datos para la tabla `tema`
--

INSERT INTO `tema` (`indice`, `entradaPrevia`, `time`, `email`, `descripcion`) VALUES
(18, 14, '2011-02-13 16:12:40', 'javidgon@gmail.com', 'Pienso que la primera es la familia.'),
(17, 15, '2011-02-13 16:12:16', 'pepe@hotmail.com', 'Ni lo sueÃ±es! Hotmail es el mejor'),
(16, 15, '2011-02-13 16:11:54', 'javidgon@gmail.com', 'GMAIL!'),
(15, -1, '2011-02-13 16:11:32', 'cristina@upo.es', 'Cual es tu gestor de correo favorito?'),
(14, -1, '2011-02-13 16:10:50', 'pepe@hotmail.com', 'Cuales son las 10 cosas mÃ¡s importantes?'),
(13, -1, '2011-02-13 16:10:10', 'javidgon@gmail.com', 'CuÃ¡l piensas que es el mejor mÃ©todo de estudio?'),
(19, 14, '2011-02-13 16:13:04', 'pepe@hotmail.com', 'Pienso que el futbol es la segunda.'),
(20, 13, '2011-02-13 16:13:22', 'javidgon@gmail.com', 'Estudiar 15 dÃ­as antes.'),
(21, 13, '2011-02-13 16:13:39', 'Cristina@upo.es', 'Estudiar 2 dÃ­as antes'),
(22, 14, '2011-02-13 16:14:49', 'javidgon@gmail.com', 'Un buen trabajo tambiÃ©n es importante.');
