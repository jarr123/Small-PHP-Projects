-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 13-02-2011 a las 16:09:39
-- Versión del servidor: 5.1.44
-- Versión de PHP: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `fotolog`
--
CREATE DATABASE `fotolog` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `fotolog`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comentario`
--

CREATE TABLE IF NOT EXISTS `comentario` (
  `email` varchar(20) NOT NULL,
  `comentario` varchar(100) NOT NULL,
  `fotografia` varchar(80) NOT NULL,
  PRIMARY KEY (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `comentario`
--

INSERT INTO `comentario` (`email`, `comentario`, `fotografia`) VALUES
('pepe@hotmail.com', 'Me apunto! Un abrazo amigos!', 'Torii.gif'),
('cristina@hotmail.com', 'La verdad es que si! Hace un dÃ­a primaveral increÃ­ble! Tenemos que ir a la playa, no creÃ©is?', 'Koi.gif'),
('javidgon@gmail.com', 'Buenos dÃ­as a todos! Empezamos un gran dÃ­a!', 'Bonsai.gif');
