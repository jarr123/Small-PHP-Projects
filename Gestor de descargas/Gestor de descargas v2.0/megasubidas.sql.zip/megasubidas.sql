-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 13-02-2011 a las 15:52:49
-- Versión del servidor: 5.1.44
-- Versión de PHP: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `megasubidas`
--
CREATE DATABASE `megasubidas` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `megasubidas`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `archivos`
--

CREATE TABLE IF NOT EXISTS `archivos` (
  `nombreArchivo` varchar(50) NOT NULL,
  `descripcion` varchar(200) NOT NULL,
  `direccion` varchar(50) NOT NULL,
  `descargas` int(11) NOT NULL,
  PRIMARY KEY (`nombreArchivo`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `archivos`
--

INSERT INTO `archivos` (`nombreArchivo`, `descripcion`, `direccion`, `descargas`) VALUES
('CatÃ¡logo de componentes Ortronics', 'CatÃ¡logo de componentes Ortronic.', '129761231003 catÃ¡logo componentes Ortronics.pdf', 1),
('SCE Agricultura y pesca', 'Documento sobre implantaciÃ³n de cableado estructurado.', '129761202501 SCE_Agricultura y Pesca.pdf', 2);
