-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 13-02-2011 a las 16:45:02
-- Versión del servidor: 5.1.44
-- Versión de PHP: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `comunio`
--
CREATE DATABASE `comunio` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `comunio`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `equipos`
--

CREATE TABLE IF NOT EXISTS `equipos` (
  `nombreLiga` varchar(30) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  PRIMARY KEY (`nombre`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `equipos`
--

INSERT INTO `equipos` (`nombreLiga`, `nombre`) VALUES
('Liga BBVA', 'Valencia'),
('Liga BBVA', 'Barcelona'),
('Liga BBVA', 'Sevilla'),
('Liga BBVA', 'Betis'),
('Liga BBVA', 'Real Madrid');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ligas`
--

CREATE TABLE IF NOT EXISTS `ligas` (
  `nombre` varchar(30) NOT NULL,
  PRIMARY KEY (`nombre`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `ligas`
--

INSERT INTO `ligas` (`nombre`) VALUES
('Liga BBVA');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `resultados`
--

CREATE TABLE IF NOT EXISTS `resultados` (
  `liga` varchar(30) NOT NULL,
  `local` varchar(30) NOT NULL,
  `visitante` varchar(30) NOT NULL,
  `golesLocal` int(11) NOT NULL,
  `golesVisitante` int(11) NOT NULL,
  PRIMARY KEY (`local`,`visitante`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `resultados`
--

INSERT INTO `resultados` (`liga`, `local`, `visitante`, `golesLocal`, `golesVisitante`) VALUES
('Liga BBVA', 'Betis', 'Valencia', 5, 2),
('Liga BBVA', 'Barcelona', 'Sevilla', 1, 2),
('Liga BBVA', 'Betis', 'Barcelona', 2, 1),
('Liga BBVA', 'Valencia', 'Sevilla', 3, 4),
('Liga BBVA', 'Betis', 'Real Madrid', 1, 2),
('Liga BBVA', 'Sevilla', 'Valencia', 5, 4),
('Liga BBVA', 'Barcelona', 'Betis', 2, 1),
('Liga BBVA', 'Real Madrid', 'Valencia', 4, 2),
('Liga BBVA', 'Betis', 'Sevilla', 3, 2),
('Liga BBVA', 'Valencia', 'Betis', 2, 1);
