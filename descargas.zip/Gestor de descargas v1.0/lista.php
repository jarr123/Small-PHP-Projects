<html>
		<head>
			<style type="text/css">
				@import "sample.css";
			</style>
		</head>
	<body>
	</body></html>
<?php
@include ('funciones.php');
	leerElementos('temas.txt');

	echo '<p class = "link"><a href="index.php" >Volver al index!</a></p>';









?>